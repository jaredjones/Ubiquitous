//
//  ProfileViewController.m
//  ShareThought
//
//  Created by UH Game and Entrepreneurship on 10/12/15.
//  Copyright © 2015 Team7. All rights reserved.
//

#import "ProfileViewController.h"

@interface ProfileViewController ()
@property (weak, nonatomic) IBOutlet UILabel *fullNameTextField;
@property (weak, nonatomic) IBOutlet UILabel *profileTextField;
@property (weak, nonatomic) IBOutlet UIImageView *profilePic;


@end

@implementation ProfileViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do view setup here.
    
    //_FullNameTextField text
    
}

@end
